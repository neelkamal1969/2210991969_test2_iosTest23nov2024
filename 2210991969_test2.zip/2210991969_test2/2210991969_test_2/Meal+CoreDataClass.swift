//
//  Meal+CoreDataClass.swift
//  2210991969_test_2
//
//  Created by student-2 on 23/11/24.
//
//

import Foundation
import CoreData

@objc(Meal)
public class Meal: NSManagedObject {

}
